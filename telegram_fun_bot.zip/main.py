from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import os

TOKEN = os.getenv("BOT_TOKEN")

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("بوت المنشن شغال يا نجم!")

async def mention_all(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.chat.type != "supergroup":
        await update.message.reply_text("الأمر ده بيشتغل بس في السوبر جروب.")
        return

    # هنذكر فقط الناس اللي ظهر ليهم يوزر نيم أو اسم
    members = await context.bot.get_chat_administrators(update.message.chat_id)
    mentions = ""
    for member in members:
        user = member.user
        if not user.is_bot:
            mentions += f"@{user.username or user.first_name} "

    await update.message.reply_text(mentions or "مفيش أعضاء أقدر أعملهم منشن.")

app = ApplicationBuilder().token(TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("منشن", mention_all))

app.run_polling()
